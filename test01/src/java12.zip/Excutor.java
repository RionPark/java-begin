package java12;

public class Excutor {

	public static void main(String[] args) {
		Lotto l = new Lotto();
		l.generateLottoNums();
		l.printLottoNums();
		InputNumbers in = new InputNumbers();
		in.inputLottoNums();
		in.macheLottoNums(l.lottoNums);
	}
}
